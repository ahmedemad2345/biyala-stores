# Deploy

* If work at Expo, you cannot deploy from `libraries/vector-icons`
  inside of universe -- you need to check out the repo from Github into
  a separate directory outside of universe.

- `yarn`
- `npm run deploy`
