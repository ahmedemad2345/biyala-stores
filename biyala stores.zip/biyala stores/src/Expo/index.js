import Expo, { Font, Components, Asset, AppLoading, WebBrowser, FacebookAds, LinearGradient, AdSettings, Google, Facebook, DangerZone, Video } from 'expo';

export { Font, Components, WebBrowser, Asset, AppLoading, LinearGradient, FacebookAds, AdSettings, Google, Facebook, DangerZone, Video };
export default Expo;

// import _LinearGradient from 'react-native-linear-gradient';
// import _Facebook from './Facebook';
// import _Google from './Google';

// export const LinearGradient = _LinearGradient

// export const Facebook = _Facebook;
// export const Google = _Google;
