/** @format */

// @flow
import React from 'react'
import { View, SafeAreaView} from 'react-native'
import { Chat } from '@containers'
import { ChatToolBar } from '@components'
import {withTheme, Styles} from '@common'

@withTheme
export default class ChatScreen extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    header: null,
    tabBarVisible: false,
  })

  _goBack = (backToRoute) => {
    const { goBack, navigate } = this.props.navigation
    if (typeof backToRoute != 'undefined') {
      navigate(backToRoute)
    } else {
      goBack()
    }
  }

  render() {
    const { getParam } = this.props.navigation
    const author = getParam('author', null)
    const backToRoute = getParam('backToRoute', undefined)

    if (author != null) {
      return (
        <SafeAreaView style={Styles.container}>
          <ChatToolBar
            onBack={() => this._goBack(backToRoute)}
            label={
              author.name
                ? author.name
                : author.last_name + ' ' + author.first_name
            }
          />
          <Chat author={author} />
        </SafeAreaView>
      )
    } else {
      return (
        <SafeAreaView style={Styles.container}>
          <ChatToolBar onBack={() => this._goBack()} label={''} />
        </SafeAreaView>
      )
    }
  }
}
