/** @format */

import React, { PureComponent } from "react";
import { WebView } from "react-native";
import { View } from "react-native";
import { CustomPage } from "@containers";

export default class CustomPageScreen extends PureComponent {
  static navigationOptions = ({ navigation }) => ({
    header: null,
  });

  render() {
    const { state } = this.props.navigation;
    if (typeof state.params == "undefined") {
      return <View />;
    }

    if (typeof state.params.url != "undefined") {
      return (
        <View style={{ flex: 1 }}>
          <WebView source={{ uri: state.params.url }} />
        </View>
      );
    }

    return (
      <View>
        <CustomPage navigation={this.props.navigation} id={state.params.id} />
      </View>
    );
  }
}
