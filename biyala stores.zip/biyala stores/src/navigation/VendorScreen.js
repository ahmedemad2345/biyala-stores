/** @format */

import React, { PureComponent } from "react";
import PropTypes from "prop-types";
import { ProductVendor } from "@components";
import { Color, Styles } from "@common";
import { Back, CartWishListIcons } from "./IconNav";

export default class VendorScreen extends PureComponent {
  static navigationOptions = ({ navigation }) => ({
    tabBarVisible: false,
    headerLeft: Back(navigation),
    headerRight: CartWishListIcons(navigation),

    headerTintColor: Color.headerTintColor,
    headerStyle: Styles.Common.toolbarFloat,
    headerTransparent: true,
  });

  static propTypes = {
    navigation: PropTypes.object.isRequired,
  };

  render() {
    const { getParam, navigate } = this.props.navigation;
    const vendor = getParam("store");

    return (
      <ProductVendor
        vendor={vendor}
        navigation={this.props.navigation}
        onViewVendor={(store) => navigate("Vendor", { store })}
        onViewProductScreen={(item) => navigate("Detail", item)}
      />
    );
  }
}
