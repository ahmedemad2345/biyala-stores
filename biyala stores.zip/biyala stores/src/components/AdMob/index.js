/** @format */

import React, { PureComponent } from "react";
import { View } from "react-native";
import css from "./styles";
import { Config } from "@common";
import { AdMobBanner, AdMobInterstitial } from "expo";

export default class Index extends PureComponent {
  componentWillUnmount() {
    AdMobInterstitial.removeAllListeners();
  }

  showInterstital() {
    AdMobInterstitial.showAd((error) => error && console.log(error));
  }

  interstitialDidClose() {
    AdMobInterstitial.requestAd((error) => error && console.log(error));
  }

  render() {
    return (
      <View style={css.body}>
        <AdMobBanner
          ref={(component) => (this._root = component)}
          bannerSize="fullBanner"
          testDeviceID={
            __DEV__
              ? "EMULATOR"
              : typeof deviceID !== "undefined"
              ? deviceID
              : Config.AdMob.deviceID
          }
          adUnitID={Config.AdMob.unitID}
        />
      </View>
    );
  }
}
