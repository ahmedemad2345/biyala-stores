/** @format */

import React, { PureComponent } from "react";
import PropTypes from "prop-types";
import {
  FlatList,
  Text,
  TouchableOpacity,
  View,
  I18nManager,
} from "react-native";
import { Constants, Images, Languages, AppConfig, withTheme } from "@common";
import Icon from "react-native-vector-icons/Entypo";
import { HorizonLayout } from "@components";
import { find } from "lodash";
import styles from "./styles";
import Categories from "./Categories";
import Promotions from "./Promotions";

class HorizonList extends PureComponent {
  static propTypes = {
    config: PropTypes.object,
    index: PropTypes.number,
    fetchPost: PropTypes.func,
    onShowAll: PropTypes.func,
    list: PropTypes.array,
    fetchProductsByCollections: PropTypes.func,
    setSelectedCategory: PropTypes.func,
    onViewProductScreen: PropTypes.func,
    showCategoriesScreen: PropTypes.func,
    collection: PropTypes.object,
  };

  constructor(props) {
    super(props);

    this.page = 1;
    this.limit = Constants.pagingLimit;
    this.defaultList = [
      {
        id: 1,
        name: Languages.loading,
        images: [Images.PlaceHolder],
      },
      {
        id: 2,
        name: Languages.loading,
        images: [Images.PlaceHolder],
      },
      {
        id: 3,
        name: Languages.loading,
        images: [Images.PlaceHolder],
      },
    ];
  }

  /**
   * handle load more
   */
  _nextPosts = () => {
    const { config, index, fetchPost, collection } = this.props;
    this.page += 1;
    if (!collection.finish) {
      fetchPost({ config, index, page: this.page });
    }
  };

  _viewAll = () => {
    const {
      config,
      onShowAll,
      index,
      list,
      fetchProductsByCollections,
      setSelectedCategory,
    } = this.props;
    const selectedCategory = find(
      list,
      (category) => category.id === config.category
    );
    setSelectedCategory(selectedCategory);
    fetchProductsByCollections(config.category, config.tag, this.page, index);
    onShowAll(config, index);
  };

  showProductsByCategory = (config) => {
    const {
      // onShowAll,
      // index,
      list,
      // fetchProductsByCollections,
      setSelectedCategory,
      onViewCategory
    } = this.props;
    const selectedCategory = find(
      list,
      (category) => category.id === config.category
    );
    setSelectedCategory(selectedCategory);
    // fetchProductsByCollections(config.category, config.tag, this.page, index);
    // onShowAll(config, index);
    onViewCategory(config);
  };

  onViewProductScreen = (product, type) => {
    this.props.onViewProductScreen({ product, type });
  };

  renderItem = ({ item, index }) => {
    const { layout } = this.props.config;

    if (item === null) return <View key="post_" />;
    return (
      <HorizonLayout
        product={item}
        key={`post-${index}`}
        onViewPost={() => this.onViewProductScreen(item, index)}
        layout={layout}
      />
    );
  };

  render() {
    const {
      showCategoriesScreen,
      collection,
      config,
      theme: {
        colors: { link, text },
      },
    } = this.props;

    const list =
      typeof collection.list !== "undefined" && collection.list.length !== 0
        ? collection.list
        : this.defaultList;
    const isPaging = !!config.paging;

    const renderHeader = () => (
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={[styles.tagHeader, { color: text }]}>
            {config.name}
          </Text>
        </View>
        {!config.hideShowAll && (
          <TouchableOpacity
            onPress={
              config.layout != Constants.Layout.circle
                ? this._viewAll
                : showCategoriesScreen
            }
            style={styles.headerRight}>
            <Text style={[styles.headerRightText, {color: link}]}>
              {Languages.seeAll}
            </Text>
            <Icon
              style={styles.icon}
              color={AppConfig.MainColor}
              size={20}
              name={
                I18nManager.isRTL ? "chevron-small-left" : "chevron-small-right"
              }
            />
          </TouchableOpacity>
        )}
      </View>
    );

    const renderContent = () => {
      const { config } = this.props;
      switch (config.layout) {
        case Constants.Layout.circle:
          return (
            <Categories
              categories={this.props.list}
              items={config.items}
              onPress={this.showProductsByCategory}
            />
          );
        default:
          return (
            <FlatList
              contentContainerStyle={styles.flatlist}
              data={list}
              keyExtractor={(item) => `post__${item.id}`}
              renderItem={this.renderItem}
              showsHorizontalScrollIndicator={false}
              horizontal
              pagingEnabled={isPaging}
              onEndReached={false && this._nextPosts}
            />
          );
      }
    };

    return (
      <View
        style={[
          styles.flatWrap,
          config.color && {
            backgroundColor: config.color,
          },
        ]}>
        {config.name && renderHeader()}
        {renderContent()}
      </View>
    );
  }
}

export default withTheme(HorizonList);
