/** @format */

import React, { PureComponent } from "react";
import { Text, TouchableOpacity, View, Image } from "react-native";
import { withTheme, Tools, Config} from "@common";
import styles from "./styles";
import { LinearGradient } from "@expo";

class Item extends PureComponent {
  render() {
    const {
      item,
      label,
      onPress,
      theme: {
        colors: { text },
      },
    } = this.props;

    if (Config.HomeCategories.theme == 1) {
      return (
        <View style={styles.container}>
          <TouchableOpacity
            style={styles.wrap}
            activeOpacity={0.75}
            onPress={() => onPress({ ...item, circle: true, name: label })}>
            
            <View style={styles.background}>
              <Image source={item.image} style={[styles.icon, {tintColor: item.colors[0]} ]} />
            </View>
            <Text style={[styles.title, { color: text }]}>
              {label && Tools.getFormatDescription(label)}
            </Text>
          </TouchableOpacity>
        </View>
      );
    }

    return (
      <View style={styles.container}>
        <TouchableOpacity
          style={styles.wrap}
          activeOpacity={0.75}
          onPress={() => onPress({ ...item, circle: true, name: label })}>
          
          <LinearGradient colors={item.colors} style={styles.button}>
            <Image source={item.image} style={[styles.icon ]} />
          </LinearGradient>
          <Text style={[styles.title, { color: text }]}>
            {label && Tools.getFormatDescription(label)}
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

export default withTheme(Item);
