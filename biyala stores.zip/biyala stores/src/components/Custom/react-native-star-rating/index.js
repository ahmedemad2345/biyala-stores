// Local file imports
import StarRating from './StarRating'

export default StarRating
