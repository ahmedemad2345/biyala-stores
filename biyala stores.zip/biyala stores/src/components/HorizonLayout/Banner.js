/** @format */

import React, { PureComponent } from "react";
import { View, Text } from "react-native";
import { Images, Styles } from "@common";
import { ImageCache, WishListIcon, Rating, TouchableScale } from "@components";
import { getProductImage, currencyFormatter } from "@app/Omni";
import { LinearGradient } from "@expo";
import css from "./style";

export default class BannerLarge extends PureComponent {
  render() {
    const { viewPost, title, store, product } = this.props;
    const imageURI =
      typeof product.images[0] !== "undefined"
        ? getProductImage(product.images[0].src, Styles.width)
        : Images.PlaceHolderURL;
    const productPrice = `${currencyFormatter(product.price)} `;
    const productPriceSale = product.on_sale
      ? `${currencyFormatter(product.regular_price)} `
      : null;

    return (
      <TouchableScale onPress={viewPost} style={css.bannerViewShadow}>
        <View activeOpacity={1} style={css.bannerView}>
          <ImageCache
            uri={imageURI}
            defaultSource={Images.imageHolder}
            style={css.bannerImage}
          />

          <LinearGradient
            colors={["rgba(255,255,255,0)", "rgba(255,255,255, 0.3)"]}
            style={css.bannerOverlay}>
            <Text style={css.bannerTitle}>
              {title} {store && ' - ' + store.toUpperCase()}
            </Text>
            <View style={css.priceView}>
              <Text style={[css.price]}>{productPrice}</Text>
              
              <Text style={[css.price, product.on_sale && css.sale_price]}>
                {productPriceSale}
              </Text>

              <Rating rating={Number(product.average_rating)}/>
            </View>
          </LinearGradient>

          <WishListIcon product={product} />
        </View>
      </TouchableScale>
    );
  }
}
