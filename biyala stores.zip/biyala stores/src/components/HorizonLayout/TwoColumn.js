/** @format */

import React, { PureComponent } from "react";
import { Text, TouchableOpacity } from "react-native";
import { Images, Styles, withTheme } from "@common";
import { WishListIcon, ImageCache, ProductPrice, Rating } from "@components";
import { getProductImage } from "@app/Omni";
import css from "./style";

class TwoColumn extends PureComponent {
  render() {
    const {
      title,
      product,
      viewPost,
      store,
      theme: {
        colors: { text, background },
      },
    } = this.props;
    const imageURI =
      typeof product.images[0] !== "undefined"
        ? getProductImage(product.images[0].src, Styles.width/2)
        : Images.PlaceHolderURL;

    return (
      <TouchableOpacity
        activeOpacity={0.9}
        style={[css.panelTwo, {backgroundColor: background} ]}
        onPress={viewPost}>
        <ImageCache
          uri={imageURI}
          defaultSource={Images.imageHolder}
          style={css.imagePanelTwo}
        />
        <Text numberOfLines={3} style={[css.nameTwo, { color: text }]}>
          {title} {store && '- ' + store.toUpperCase()}
        </Text>

        

        <ProductPrice product={product} hideDisCount />

        <WishListIcon product={product} />

        <Rating rating={Number(product.average_rating)}/>
      </TouchableOpacity>
    );
  }
}

export default withTheme(TwoColumn);
