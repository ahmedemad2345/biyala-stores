/** @format */

import React from "react";
import {
  Text,
  Image,
  Dimensions,
  StyleSheet,
  View,
  TouchableOpacity,
} from "react-native";
import {
  Languages,
  AppConfig,
  Constants,
  withTheme,
  Tools,
  Images,
} from "@common";
import { Rating } from "@components";
import { isObject } from "lodash";
import { getProductImage } from "@app/Omni";
const { width, height } = Dimensions.get("window");

@withTheme
class VendorInfo extends React.PureComponent {
  renderRating = () => {
    const {
      vendor,
      theme: {
        colors: { text, lineColor },
      },
    } = this.props;

    if (vendor && typeof vendor.rating !== "undefined") {
      return (
        <View
          style={[
            styles.row,
            Constants.RTL && { flexDirection: "row-reverse" },
          ]}>
          <View style={[styles.lbContainer, { backgroundColor: lineColor }]}>
            <Text style={[styles.label, { color: text }]}>
              {Languages.storeRating}
            </Text>
          </View>

          <View style={[styles.lbRating]}>
            <Rating rating={Number(vendor.rating.rating)} />
            <Text style={[{ marginLeft: 8, color: text }]}>
              {`${vendor.rating.count} ${Languages.review}`}
            </Text>
          </View>
        </View>
      );
    }
  };

  getVendorAdress = () => {
    const { vendor } = this.props;

    let str = "";
    if (
      vendor &&
      typeof vendor.address !== "undefined" &&
      vendor.address != ""
    ) {
      if (!AppConfig.WooCommerce.useWCV && isObject(vendor.address)) {
        str = `${vendor.address.street_1}, ${vendor.address.city}, ${
          vendor.address.state
        }`;
      } else {
        str = vendor.address;
      }
    } else if (
      vendor &&
      typeof vendor.billing_address_1 !== "undefined" &&
      vendor.billing_address_1 != ""
    ) {
      str = vendor.billing_address_1;
    }
    // console.log([str, vendor]);
    return str;
  };

  render() {
    const {
      vendor,
      theme: {
        colors: { text, lineColor, link },
      },
    } = this.props;

    const email =
      vendor && vendor.email
        ? vendor.email
        : vendor && vendor.billing_email && vendor.billing_email;
    const phone =
      vendor && vendor.phone
        ? vendor.phone
        : vendor && vendor.billing_phone && vendor.billing_phone;

    const store = [
      { name: Languages.storeName, value: Tools.getShopName(vendor) },
      { name: Languages.storeAddress, value: this.getVendorAdress() },
    ];

    if (typeof email != "undefined") {
      store.push({
        name: Languages.storeEmail,
        value: email,
      });
    }

    if (typeof phone != "undefined") {
      store.push({
        name: Languages.storePhone,
        value: phone,
      });
    }

    const attributes = [];

    for (let i = 0; i < store.length; i++) {
      attributes.push(
        <View
          key={i}
          style={[
            styles.row,
            Constants.RTL && { flexDirection: "row-reverse" },
          ]}>
          <View style={[styles.lbContainer, { backgroundColor: lineColor }]}>
            <Text style={[styles.label, { color: text }]}>{store[i].name}</Text>
          </View>
          <View style={[styles.lbValue]}>
            <Text style={[styles.value, { color: text }]}>
              {store[i].value}
            </Text>
          </View>
        </View>
      );
    }

    const bannerImg =
      typeof vendor.banner !== "undefined" && vendor.banner != ""
        ? { uri: getProductImage(vendor.banner, Styles.width) }
        : typeof vendor.pv_logo_image !== "undefined" &&
          vendor.pv_logo_image != ""
        ? { uri: getProductImage(vendor.pv_logo_image, Styles.width) }
        : Images.categoryPlaceholder;

    return (
      <View style={[styles.container, { backgroundColor: lineColor }]}>
        <Image style={styles.bannerImage} source={bannerImg} />
        {attributes}
        {this.renderRating()}

        <View
          style={[
            styles.row,
            Constants.RTL && { flexDirection: "row-reverse" },
          ]}>
          <View style={[styles.lbContainer, { backgroundColor: lineColor }]} />
          {this.props.viewVendor && <View style={[styles.lbValue]}>
            <TouchableOpacity
              activeOpacity={0.9}
              onPress={this.props.viewVendor}>
              <Text style={[styles.valueLink, { color: link }]}>{Languages.Details}</Text>
            </TouchableOpacity>
          </View>}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(255,255,255,1)",
    width: width - 40,
    margin: 20,
    borderRadius: 9,
    paddingBottom: 8,
  },
  row: {
    flexDirection: "row",
    minHeight: 40,
  },
  lbContainer: {
    flex: 0.3,
    justifyContent: "center",
    alignItems: "flex-end",
    paddingRight: 4,
    borderRightWidth: 0.5,
    borderRightColor: "#CED7DD",
    backgroundColor: "rgba(255,255,255,1)",
  },
  lbValue: {
    flex: 0.7,
    justifyContent: "center",
  },
  lbRating: {
    flex: 0.7,
    justifyContent: "flex-start",
    alignItems: "center",
    flexDirection: "row",
  },
  label: {
    margin: 5,
    fontSize: 14,
    fontWeight: "bold",
    textAlign: "center",
    opacity: 0.7,
  },
  value: {
    margin: 5,
    marginLeft: 10,
    color: "#5B5B5B",
    fontSize: 15,
  },
  valueLink: {
    margin: 5,
    marginLeft: 10,
    fontSize: 13,
  },
  emptyvendor: {
    height: 100,
    justifyContent: "center",
    alignItems: "center",
    padding: 10,
    backgroundColor: "rgba(255,255,255,1)",
  },

  bannerImage: {
    width: width - 40,
    resizeMode: "cover",
    marginBottom: 10,
    borderRadius: 6,
    flex: 1,
    height: (16 * height) / 100,
  },
});

export default VendorInfo;
