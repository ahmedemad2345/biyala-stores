/** @format */

import React, { Component } from "react";
import { View, Text } from "react-native";
import wp from "@services/WPAPI";
import { Back } from "@navigation/IconNav";
import { Languages } from "@common";
import WebView from "@components/WebView/WebView";
import styles from "./styles";

export default class CustomPage extends Component {
  constructor(props) {
    super(props);
    this.state = { html: "" };
    this.fetchPage = this.fetchPage.bind(this);
  }

  componentWillMount() {
    this.fetchPage(this.props.id);
  }

  componentWillReceiveProps(nextProps) {
    this.fetchPage(nextProps.id);
  }

  fetchPage(id) {
    wp.pages()
      .id(id)
      .get((err, data) => {
        if (data) {
          this.setState({
            html:
              typeof data.content.rendered !== "undefined"
                ? data.content.rendered
                : "Content is updating",
          });
        }
      });
  }

  render() {
    const { navigation } = this.props;
    return (
      <View style={{ flex: 1 }}>
        <View style={styles.headerView}>
          <Text style={styles.headerLabel}>{Languages.Cart}</Text>
          <View style={styles.homeMenu}>{Back(navigation)}</View>
        </View>
        <WebView html={this.state.html} />
      </View>
    );
  }
}
