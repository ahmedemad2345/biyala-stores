/** @format */

import React, {
  Platform,
  StyleSheet,
  Dimensions,
  PixelRatio,
} from "react-native";
import { Color, Config, Device, Constants, Styles } from "@common";

const { width, height, scale } = Dimensions.get("window"),
  vw = width / 100,
  vh = height / 100,
  vmin = Math.min(vw, vh),
  vmax = Math.max(vw, vh);

export default StyleSheet.create({
  wrap: {
    flex: 1,
  },
  html: {
    paddingLeft: 10,
    paddingRight: 10,
  },
  body: {
    paddingTop: Platform.OS == "android" ? 0 : 30,
    backgroundColor: "#eee",
    flex: 1,
  },

  //Empty
  headerLabel: {
    color: "#333",
    fontSize: 28,
    fontFamily: Constants.fontHeader,
    marginBottom: 0,
    marginLeft: 22,
    position: "absolute",
    ...Platform.select({
      ios: {
        top: 60,
      },
      android: {
        top: 50,
      },
    }),
  },
  headerView: {
    width,
    ...Platform.select({
      ios: {
        height: 60,
      },
      android: {
        height: Config.showStatusBar ? 70 : 50,
      },
    }),
  },
  homeMenu: {
    marginLeft: 8,
    position: "absolute",
    ...Platform.select({
      ios: {
        top: Device.isIphoneX ? 50 : 22,
      },
      android: {
        top: Config.showStatusBar ? 30 : 10,
      },
    }),
    zIndex: 9,
  },
});
