/** @format */

"use strict";

import React, { Component } from "react";
import { Text, ScrollView, Animated, View } from "react-native";
import { AnimatedHeader } from "@components";
import css from "./style";
import { Languages } from "@common";
import LangSwitcher from "./LangSwitch";

export default class Setting extends Component {
  state = { scrollY: new Animated.Value(0) };
  render() {
    const { navigation } = this.props;
    return (
      <ScrollView style={css.wrap}>
        <AnimatedHeader
          scrollY={this.state.scrollY}
          hideIcon
          label={Languages.Settings}
          navigation={navigation}
        />
        <View style={css.boxSetting}>
          <Text style={css.text}>{Languages.changeLanguage}:</Text>
          <LangSwitcher />
        </View>
      </ScrollView>
    );
  }
}
