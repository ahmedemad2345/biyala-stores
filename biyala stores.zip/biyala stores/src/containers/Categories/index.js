/** @format */

// @flow
/**
 * Created by InspireUI on 19/02/2017.
 */
import React from "react";
import { View } from "react-native";
import { withTheme, Languages } from "@common";
import ScrollableTabView, {
  ScrollableTabBar,
} from "react-native-scrollable-tab-view";
import styles from "./styles";
import CategoriesTab from "./CategoriesTab";
import VendorTab from "./VendorTab";

@withTheme
export default class CategoriesScreen extends React.PureComponent {
  render() {
    const {
      theme: {
        colors: { background },
      },
      onViewVendor,
      onViewCategory,
      onViewProductScreen,
    } = this.props;

    return (
      <View style={{ flex: 1, paddingTop: 0, backgroundColor: background }}>
        <ScrollableTabView
          initialPage={0}
          locked={false}
          tabBarUnderlineStyle={styles.activeTab}
          tabBarActiveTextColor="#333"
          tabBarInactiveTextColor="#ddd"
          // style={styles.containerTab}
          tabBarTextStyle={styles.textTab}
          renderTabBar={() => (
            <ScrollableTabBar
              underlineHeight={0}
              style={{ borderBottomColor: "transparent" }}
              tabsContainerStyle={{ paddingLeft: 0, paddingRight: 0 }}
              tabStyle={styles.tab}
            />
          )}>
          <CategoriesTab
            onViewCategory={onViewCategory}
            onViewProductScreen={onViewProductScreen}
            tabLabel={Languages.Categories}
          />
          <VendorTab onViewVendor={onViewVendor} tabLabel={Languages.Vendors} />
        </ScrollableTabView>
      </View>
    );
  }
}
