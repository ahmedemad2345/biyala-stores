/** @format */

// @flow
/**
 * Created by InspireUI on 19/02/2017.
 */
import React from "react";
import { View, ScrollView, Image, Text, TouchableOpacity } from "react-native";
import { connect } from "react-redux";
import { Config, Tools, Images, Styles, withTheme } from "@common";
import { LogoSpinner } from "@components";
import { BlockTimer, getProductImage } from "@app/Omni";
import Icon from "@expo/vector-icons/FontAwesome";
import { isObject } from "lodash";
import styles from "./styles";

class VendorTab extends React.PureComponent {
  componentDidMount() {
    const { fetchAllVendors } = this.props;
    fetchAllVendors();
  }

  onRowClickVendor = (item) => {
    const { onViewVendor } = this.props;
    BlockTimer.execute(() => {
      onViewVendor(item);
    }, 500);
  };

  render() {
    const {
      theme: {
        colors: { background },
      },
      list,
      isFetching,
    } = this.props;

    if (isFetching) {
      return <LogoSpinner fullStretch />;
    }

    return (
      <View style={{ flex: 1, paddingTop: 0, backgroundColor: background }}>
        <ScrollView style={[styles.fill, { backgroundColor: background }]}>
          {typeof list !== "undefined" &&
            list.length > 0 &&
            list.map((item, index) => {
              const image =
                typeof item.banner !== "undefined" && item.banner != ""
                  ? { uri: getProductImage(item.banner, Styles.width)  }
                  : typeof item.pv_logo_image !== "undefined" &&
                    item.pv_logo_image != ""
                  ? { uri: getProductImage(item.pv_logo_image, Styles.width)  }
                  : Images.categoryPlaceholder;

              const vendorAddress =
                typeof item.address !== "undefined" &&
                (item.address.length > 0 || isObject(item.address)) &&
                item.address.street_1 != ""
                  ? `${item.address.street_1}, ${item.address.city}, ${
                      item.address.state
                    }`
                  : typeof item.billing_address_1 !== "undefined" &&
                    item.billing_address_1 != ""
                  ? item.billing_address_1
                  : "";

              const emailStore =
                typeof item.email !== "undefined" && item.email != ""
                  ? item.email
                  : item.billing_email != ""
                  ? item.billing_email
                  : "";

              // console.log([item, emailStore, item.billing_email]);
              const rearrange = index % 2 == 0 ? "flex-end" : "flex-start";
              const textStyle =
                index % 2 == 0
                  ? { marginRight: 15, textAlign: "right" }
                  : { marginLeft: 15 };

              return (
                <TouchableOpacity
                  key={index.toString()}
                  style={[
                    styles.containerStyle,
                    Config.Theme.isDark ? styles.overlayDark : styles.overlay,
                    { alignItems: rearrange },
                  ]}
                  onPress={() => this.onRowClickVendor(item)}>
                  <Image style={styles.image} source={image} />
                  <View style={[styles.dim_layout]}>
                    <Text style={[styles.mainCategoryText, { ...textStyle }]}>
                      {Tools.getDescription(
                        item.store_name ? item.store_name : item.pv_shop_name
                      )}
                    </Text>
                    {vendorAddress != "" && (
                      <View
                        style={[
                          {
                            flexDirection: "row",
                            justifyContent: rearrange,
                            alignItems: "center",
                            marginLeft: 15,
                          },
                          textStyle,
                        ]}>
                        <Icon
                          name="location-arrow"
                          style={[{ margin: 5 }]}
                          color="#FFF"
                          size={12}
                        />
                        <Text style={styles.numberOfProductsText}>
                          {vendorAddress}
                        </Text>
                      </View>
                    )}
                    {emailStore != "" && (
                      <View
                        style={[
                          {
                            flexDirection: "row",
                            justifyContent: rearrange,
                            alignItems: "center",
                          },
                          textStyle,
                        ]}>
                        <Icon
                          name="envelope-open"
                          style={[{ margin: 5 }]}
                          color="#FFF"
                          size={12}
                        />
                        <Text style={styles.numberOfProductsText}>
                          {emailStore}
                        </Text>
                      </View>
                    )}
                  </View>
                </TouchableOpacity>
              );
            })}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = ({ vendor }) => {
  return {
    list: vendor.list,
    isFetching: vendor.isFetching,
  };
};

function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  const { actions } = require("@redux/VendorRedux");

  return {
    ...ownProps,
    ...stateProps,
    fetchAllVendors: () => {
      actions.fetchAllVendors(dispatch);
    },
  };
}

export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    mergeProps
  )(VendorTab)
);
