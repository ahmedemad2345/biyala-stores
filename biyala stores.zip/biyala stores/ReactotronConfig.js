/** @format */

import Reactotron, {
  trackGlobalErrors,
  openInEditor,
} from "reactotron-react-native";
import { reactotronRedux as reduxPlugin } from "reactotron-redux";
import Expo from "expo";

console.disableYellowBox = true;

if (Expo.Constants.isDevice) {
  // test on real device: change to your local config
  Reactotron.configure({ name: "Biyala Stores", host: "192.168.1.7" });
} else {
  Reactotron.configure({ name: "Biyala Stores" });
}
Reactotron.useReactNative({
  asyncStorage: { ignore: ["secret"] },
});

Reactotron.use(reduxPlugin());

if (__DEV__) {
  Reactotron.use(trackGlobalErrors())
    .use(openInEditor())
    .connect();
  Reactotron.clear();
}

console.tron = Reactotron;
